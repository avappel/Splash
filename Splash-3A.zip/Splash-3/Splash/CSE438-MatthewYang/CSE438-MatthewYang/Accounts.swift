//
//  Accounts.swift
//  CSE438-MatthewYang
//
//  Created by Matthew Yang on 11/24/18.
//  Copyright © 2018 Matthew Yang. All rights reserved.
//
// Help from: https://stackoverflow.com/questions/25510081/how-to-allow-user-to-pick-the-image-with-swift

import UIKit

class Accounts: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet weak var profileImage: UIImageView!
    
    var imagePicker:UIImagePickerController? = UIImagePickerController()

    override func viewDidLoad() {
        super.viewDidLoad()
        profileImage.layer.cornerRadius = profileImage.frame.size.width/2
        profileImage.clipsToBounds = true
        
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        profileImage.isUserInteractionEnabled = true
        profileImage.addGestureRecognizer(tapGestureRecognizer)
        
        // Uncomment the following line to preserve selection between presentations
        self.clearsSelectionOnViewWillAppear = false
        imagePicker?.delegate = self
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        //let tappedImage = tapGestureRecognizer.view as! UIImageView
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            print("Button capture")

            //imagePicker.delegate = self
            imagePicker?.sourceType = .savedPhotosAlbum
            
            imagePicker?.allowsEditing = true
            self.present(imagePicker!, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        print("the picker is \(picker)")
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage
        profileImage.image = image
        imagePicker?.dismiss(animated: true, completion: nil)
        //pickImageCallback?(image)
        
    }
//    func imagePickerController(picker: UIImagePickerController!, didFinishPickingImage image: UIImage!, editingInfo: NSDictionary!){
//        //print ("hey")
//        self.dismiss(animated: true, completion: { () -> Void in
//
//        })
//
//        profileImage.image = image
//    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 5
    }

    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func closeAccount(_ sender: Any) {
//        let otherVC = self.navigationController
//        let navVC = self.parent as? UINavigationController
//        let vcsCount = self.navigationController?.viewControllers.count
//        let theVC = self.navigationController?.viewControllers[vcsCount! - 2] as! SideMenu
//        print(otherVC)
//        print(navVC)
//        //let theVC = navVC?.presentingViewController
//        print(theVC)
        
        SideMenu.theImage = profileImage.image!
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
    
    }
}
