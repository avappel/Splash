//
//  ReviewViewController.swift
//  CSE438-MatthewYang
//
//  Created by labuser on 11/27/18.
//  Copyright © 2018 Matthew Yang. All rights reserved.
//

import UIKit

class ReviewsViewController: UIViewController {


    @IBOutlet weak var star: StarBar!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        star.color = UIColor(red: 255.0/255.0, green: 205.0/255.0, blue: 55.0/255.0, alpha: 1.0)
        //star.color = UIColor(red: 255, green: 175, blue: 55, alpha: 1.0)
        star.animateValue(to: 0.5)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
