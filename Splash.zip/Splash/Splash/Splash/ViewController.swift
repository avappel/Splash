//
//  ViewController.swift
//  Splash
//
//  Created by Alex Appel on 11/5/18.
//  Copyright © 2018 Alex Appel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

